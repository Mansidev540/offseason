<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/club_signup', [App\Http\Controllers\HomeController::class, 'club_signup'])->name('club_signup');
Route::get('/athlete_signup', [App\Http\Controllers\HomeController::class, 'athlete_signup'])->name('athlete_signup');
Route::get('/club-profile', [App\Http\Controllers\ClubController::class, 'index'])->name('club_profile');
Route::get('/athlete-profile', [App\Http\Controllers\AthleteController::class, 'index'])->name('athlete_profile');
Route::post('/club-add', [App\Http\Controllers\ClubController::class, 'save'])->name('club_save');
Route::post('/athlete_add', [App\Http\Controllers\AthleteController::class, 'save'])->name('athlete_save');
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::group(['prefix' => 'setting','middleware' =>'auth',"as"=>"setting."], function () {
    Route::get('/index', [App\Http\Controllers\SettingController::class, 'index'])->name('index');
    Route::get('/club-account', [App\Http\Controllers\AccountController::class, 'club_index'])->name('club_account');
    Route::get('/athlete-account', [App\Http\Controllers\AccountController::class, 'athlete_index'])->name('athlete_account');
    Route::post('/athlete_update', [App\Http\Controllers\AccountController::class, 'AthleteUpdate'])->name('athlete_update');
    Route::post('/club_update', [App\Http\Controllers\AccountController::class, 'ClubUpdate'])->name('club_update');
    Route::get('/password-security', [App\Http\Controllers\PasswordSecurityController::class, 'index'])->name('password_security');
    Route::get('/opration', [App\Http\Controllers\OprationController::class, 'index'])->name('opration');
    Route::post('/opration_save', [App\Http\Controllers\OprationController::class, 'OprationSave'])->name('opration_save');
    Route::post('/account_name', [App\Http\Controllers\PasswordSecurityController::class, 'account_name'])->name('account_name');
    Route::post('/account_phoneno', [App\Http\Controllers\PasswordSecurityController::class, 'account_phoneno'])->name('account_phoneno');
    Route::post('/account_email', [App\Http\Controllers\PasswordSecurityController::class, 'account_email'])->name('account_email');
    Route::post('/account_password', [App\Http\Controllers\PasswordSecurityController::class, 'account_password'])->name('account_password');
});
Route::group(['prefix' => 'rental','middleware' =>'auth',"as"=>"rental."], function () {
    Route::get('/index', [App\Http\Controllers\RentalController::class, 'index'])->name('index');
    Route::get('/add', [App\Http\Controllers\RentalController::class, 'add'])->name('add');
    Route::post('/save', [App\Http\Controllers\RentalController::class, 'save'])->name('save');
    Route::get('/edit/{id}', [App\Http\Controllers\RentalController::class, 'edit'])->name('edit');
    Route::post('/update', [App\Http\Controllers\RentalController::class, 'update'])->name('update');
    Route::get('/delete/{id}', [App\Http\Controllers\RentalController::class, 'delete'])->name('delete');
});
Route::group(['prefix' => 'service','middleware' =>'auth',"as"=>"service."], function () {
    Route::get('/index', [App\Http\Controllers\ServiceController::class, 'index'])->name('index');
    Route::get('/add', [App\Http\Controllers\ServiceController::class, 'add'])->name('add');
    Route::post('/save', [App\Http\Controllers\ServiceController::class, 'save'])->name('save');
    Route::get('/edit/{id}', [App\Http\Controllers\ServiceController::class, 'edit'])->name('edit');
    Route::post('/update', [App\Http\Controllers\ServiceController::class, 'update'])->name('update');
    Route::get('/delete/{id}', [App\Http\Controllers\ServiceController::class, 'delete'])->name('delete');
});
Route::group(['prefix' => 'club','middleware' =>'auth',"as"=>"club."], function () {
    Route::get('/index', [App\Http\Controllers\ClubModuleController::class, 'index'])->name('index');
    Route::get('/detail/{id}', [App\Http\Controllers\ClubModuleController::class, 'detail'])->name('detail');
});
Route::group(['prefix' => 'roster','middleware' =>'auth',"as"=>"roster."], function () {
    Route::get('/index', [App\Http\Controllers\RosterController::class, 'index'])->name('index');
    Route::get('/detail/{id}', [App\Http\Controllers\RosterController::class, 'detail'])->name('detail');
});

