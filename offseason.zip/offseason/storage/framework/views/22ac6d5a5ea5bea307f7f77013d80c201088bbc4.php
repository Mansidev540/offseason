

<?php $__env->startSection('content'); ?>
<div class="right-panel p-4">
    <h2 class="pb-4">SETTINGS</h2>
    <ul class="main-links">
    <?php if(Auth::user()->role == "athelet"): ?>
        <li><a href="<?php echo e(route('setting.athlete_account')); ?>">Account</a></li>
    <?php else: ?>
    <li><a href="<?php echo e(route('setting.club_account')); ?>">Account</a></li>
    <?php endif; ?>
        <li><a href="<?php echo e(route('setting.password_security')); ?>">PASSWORD & SECURITY</a></li>
        <?php if(Auth::user()->role == "club" ): ?>
        <li><a href="<?php echo e(route('setting.opration')); ?>">OPRATION</a></li>
        <?php endif; ?>
        <li><a href="">Wallet</a></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\offseason\resources\views/setting/index.blade.php ENDPATH**/ ?>