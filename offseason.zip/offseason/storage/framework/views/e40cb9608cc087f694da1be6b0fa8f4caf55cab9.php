


<?php $__env->startSection('content'); ?>
<div class="right-panel p-4">
    <div class="d-flex pb-4">
        <div class="flex-grow-1 d-flex align-items-center">
            <h2 class="text-uppercase me-4 mb-0">Club</h2>
                <!-- <div class="form-group">
                    <input type="search" class="form-control mb-0 search-input" placeholder="Search" />
                </div> -->
           
        </div>

    </div>
    <!-- <div class="listing-data px-3">
        <div class="row border-bottom py-3 list-head">
            <div class="col-sm-8 col-lg-10">Name</div>
            <div class="col-sm-2 col-lg-1">Price</div>
            <div class="col-sm-2 col-lg-1"></div>
        </div>
       
      

    </div>-->
    <div class="table-responsive pb-5 pt-4">
        <table class="table dt-responsive nowrap" id="responsive-data-table">
            <!-- <tr>
                <th width="75%" class="py-3">Name</th>
                <th width="15%" class="py-3">Price</th>
                <th width="10%" class="py-3"></th>
            </tr> -->
            <!-- <thead>
                <tr>
                    <th width="25%" class="py-3">Name</th>
                    <th width="30%" class="py-3">Location</th>
                    <th width="30%" class="py-3">Number</th>
                    <th width="30%" class="py-3">Status</th>
                </tr>
            </thead> -->
            <thead>
                        <tr>
                        <th width="25%" class="py-3">Name</th>
                        <th width="30%" class="py-3">Location</th>
                        <th width="30%" class="py-3">Number</th>
                        <th width="30%" class="py-3">Status</th>
                        </tr>
                    </thead>
            <?php $__currentLoopData = $club; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="py-4">
                    <table cellpadding="0" cellspacing="0" width="100%" class="border-none">
                        <tr>
                            <td width="80">
                                <a href="<?php echo e(route('club.detail',$value->id)); ?>"><img src="<?php echo e(asset('asset/images/MexicoSummer19-2.png')); ?>" alt="" width="56"></a>
                            </td>
                            <td><a href="<?php echo e(route('club.detail',$value->id)); ?>" class="link"><?php echo e($value->club_name); ?></a></td>
                        </tr>
                    </table>

                </td>
                <td class="py-4" valign="middle"><?php echo e($value->city); ?>,<?php echo e($value->state); ?></td>
                <td class="py-4" valign="middle"><?php echo e($value->phone_no); ?></td>
                <td class="py-4" valign="middle" style="color:green">Available</td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>
       
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<!-- <script>
$(document).ready( function () {
    $('#responsive-data-table').DataTable();
} );
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\offseason\resources\views/club/index.blade.php ENDPATH**/ ?>