


<?php $__env->startSection('content'); ?>
<div class="right-panel p-4">
    <div class="d-flex pb-4">
        <div class="flex-grow-1 d-flex align-items-center">
            <h2 class="text-uppercase me-4 mb-0">Roster</h2>
                <!-- <div class="form-group">
                    <input type="search" class="form-control mb-0 search-input" placeholder="Search" />
                </div> -->
           
        </div>
        <div class="flex-shrink-0">
            <a href="javascript:void(0)" data-toggle="modal" data-target="#id_model" class="btn button btn3">Add Roster</a>
        </div>

    </div>
    <!-- <div class="listing-data px-3">
        <div class="row border-bottom py-3 list-head">
            <div class="col-sm-8 col-lg-10">Name</div>
            <div class="col-sm-2 col-lg-1">Price</div>
            <div class="col-sm-2 col-lg-1"></div>
        </div>
       
      

    </div>-->
    <div class="modal fade" id="id_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content ">
                    <h2 class="text-center">New Roster</h2>
                    <div class="modal-body">
                        <p class="text-center">Send an email invite to add a new roster.</p>
                        <input type="text" name="email" class="form-control mb-0">
                        <div class="d-flex justify-content-center pt-4">
                        <a href="" class="btn btn-primary me-5">Send</a>
                            <a href="" class="btn btn-primary">Cancle</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <div class="table-responsive pb-5 pt-4">
        <table class="table dt-responsive nowrap" id="responsive-data-table">
            <!-- <tr>
                <th width="75%" class="py-3">Name</th>
                <th width="15%" class="py-3">Price</th>
                <th width="10%" class="py-3"></th>
            </tr> -->
            <!-- <thead>
                <tr>
                    <th width="25%" class="py-3">Name</th>
                    <th width="30%" class="py-3">Location</th>
                    <th width="30%" class="py-3">Number</th>
                    <th width="30%" class="py-3">Status</th>
                </tr>
            </thead> -->
            <thead>
                        <tr>
                        <th width="25%" class="py-3">Name</th>
                        <th width="30%" class="py-3">Location</th>
                        <th width="30%" class="py-3">Number</th>
                        <th width="30%" class="py-3">Status</th>
                        </tr>
                    </thead>
            <?php $__currentLoopData = $roster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="py-4">
                    <table cellpadding="0" cellspacing="0" width="100%" class="border-none">
                        <tr>
                            <td width="80">
                                <a href="<?php echo e(route('roster.detail',$value->id)); ?>"><img src="<?php echo e(asset('asset/images/MexicoSummer19-2.png')); ?>" alt="" width="56"></a>
                            </td>
                            <td><a href="<?php echo e(route('roster.detail',$value->id)); ?>" class="link"><?php echo e($value->athlete_name); ?></a></td>
                        </tr>
                    </table>

                </td>
                <td class="py-4" valign="middle"><?php echo e($value->city); ?>,<?php echo e($value->state); ?></td>
                <td class="py-4" valign="middle"><?php echo e($value->phone_no); ?></td>
                <td class="py-4" valign="middle" style="color:green">Available</td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>
       
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<!-- <script>
$(document).ready( function () {
    $('#responsive-data-table').DataTable();
} );
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\offseason\resources\views/roster/index.blade.php ENDPATH**/ ?>