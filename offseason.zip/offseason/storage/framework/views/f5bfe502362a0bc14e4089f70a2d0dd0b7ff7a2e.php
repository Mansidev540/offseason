<!-- <!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

 
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>


    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

 
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

 
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>



</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <ul class="navbar-nav ms-auto">
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4"> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFSEASON</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/custom.css')); ?>" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">

    <style>

        .error{
            color:red !important;
            
        }

    </style>
</head>

<body>

    <header class="p-4 pb-3 fixed-top">
        <div class="d-flex justify-content-between">
            <div class="logo text-uppercase">
                <?php
                $user = DB::table('users')->where('id',Auth::user()->id)->first();
                if($user->role == "club"){
                ?>
                
                <img src="<?php echo e(asset('asset/images/Offszn.png')); ?>" alt="OFFSEASON" width="100"> <strong>Club</strong>
                <?php } else{ ?>
                  <img src="<?php echo e(asset('asset/images/Offszn.png')); ?>" alt="OFFSEASON" width="100"> <strong>Athlete</strong>  
                <?php } ?>
            </div>
            <div class="right-side d-flex">
                <div class="admin-name">
                    <?php
                    if($user->role == "club"){
                        $club = DB::table('club')->where('user_id',Auth::user()->id)->first();
                        ?>
                        <strong class="pe-3 text-uppercase"><?php echo e($club->club_name); ?></strong> <img src="<?php echo e(asset('asset/images/MexicoSummer19-2.png')); ?>" alt="" width="40">
                        <?php } else{ ?>
                            <strong class="pe-3 text-uppercase"><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->l_name); ?></strong> <img src="<?php echo e(asset('asset/images/MexicoSummer19-2.png')); ?>" alt="" width="40">  
                        <?php } ?>
                    
                </div>
                <div class="px-3 d-none menu-icon">
                    <a href="#"><span class="bar"></span><span class="bar"></span><span class="bar"></span></a>
                </div>
            </div>
        </div>
    </header>
    <section class="content-area position-relative">
        <div class="d-flex">
            <div class="left-panel p-4">
                <nav>
                    <ul>
                        <!-- <li><a href="calendar.html">Calendar</a></li>
                        <li><a href="club.html">Clubs</a></li> -->
                        <?php if($user->role == "club"){ ?>
                        <li><a href="<?php echo e(route('roster.index')); ?>">Roster</a></li>
                        <li><a href="<?php echo e(route('rental.index')); ?>">Rentals</a></li>
                        <li><a href="<?php echo e(route('service.index')); ?>">Services</a></li>
                        <?php }else{?>
                            <li><a href="<?php echo e(route('club.index')); ?>">Club</a></li>
                           <?php }?>
                        <li><a href="balance.html">Balance</a></li>
                        <li><a href="<?php echo e(route('setting.index')); ?>">Settings</a></li>
                        <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                        </li>
                    </ul>
                </nav>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
</section>








<script src="<?php echo e(asset('asset/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/bootstrap.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"> </script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"> </script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.js"></script>
<script src="<?php echo e(asset('asset/js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\offseason\resources\views/layouts/app.blade.php ENDPATH**/ ?>