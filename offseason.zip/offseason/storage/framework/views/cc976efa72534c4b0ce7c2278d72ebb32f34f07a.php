

<?php $__env->startSection('content'); ?>
<div class="right-panel p-4">
    <div class="breadcrumb">
        <div><a href="<?php echo e(route('setting.index')); ?>" class="text-uppercase"><u>Settings</u></a></div>
        <div class="arrow mx-3"><i class="fa fa-angle-right"></i></div>
        <div class="text-uppercase"><u>PASSWORD & Security</u></div>
    </div>
    <div class="edit-info pt-4">
    <?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
        <!-- <form action=""> -->
            <div class="pb-5">
            <?php if(Auth::user()->role == "athelet" ): ?>
                <label for="">Athlete</label>
            <?php else: ?>
            <label for="">Club Ownar</label>
            <?php endif; ?>
                <div class="row pt-2">
                    <div class="col-12 col-md-6">
                        <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->l_name); ?>

                    </div>
                    <div class="col-12 col-md-6">
                    <?php if(Auth::user()->role == "athelet" ): ?>
                    <a href="javascript:void(0)" data-toggle="modal" data-target="#change-athlete">Change Athlete</a>
                    <?php else: ?>
                    <a href="javascript:void(0)" data-toggle="modal" data-target="#change-athlete">Change Club Ownar</a>
                    <?php endif; ?>
                        
                    </div>
                </div>
                <div class="modal fade" id="change-athlete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content ">
                            <div class="px-3 text-center">
                            <?php if(Auth::user()->role == "athelet" ): ?>
                            <h5 class="modal-title" id="exampleModalLabel">Change Athlete</h5>
                            <?php else: ?>
                            <h5 class="modal-title" id="exampleModalLabel">Change Club Ownar</h5>
                            <?php endif; ?>
                                
                                <button type="button" class="close border-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                            <form id="profile" method="POST" action="<?php echo e(route('setting.account_name')); ?>">
                            <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="pb-2">New Name</label>
                                            <div class="col-12 col-sm-6">
                                                <input type="text" class="form-control" placeholder="First" name="name" value="<?php echo e($user->name); ?> ">
                                            </div>
                                            <div class="col-12 col-sm-6">
                                                <input type="text" class="form-control" placeholder="Last" name="l_name" value="<?php echo e($user->l_name); ?> ">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="pb-2">Password</label>
                                        <input type="password" class="form-control" placeholder="" name="password">
                                    </div>
                                    <div class="d-flex justify-content-end pt-4">
                                        <button type="submit" class="btn btn-primary" >Save</button>
                                    </div>

                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="pb-5">
                <label for="">Phone Number</label>
                <div class="row pt-2">
                    <div class="col-12 col-md-6">
                    <?php echo e(Auth::user()->phone_no); ?>

                    </div>
                    <div class="col-12 col-md-6">
                        <a href="javascript:void(0)" data-toggle="modal" data-target="#change-phone-number">Change Phone Number</a>
                    </div>
                </div>
                <div class="modal fade" id="change-phone-number" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content ">
                            <div class="px-3 text-center">
                                <h5 class="modal-title" id="exampleModalLabel">Change Phone Number</h5>
                                <button type="button" class="close border-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                            <form id="profile" method="POST" action="<?php echo e(route('setting.account_phoneno')); ?>">
                            <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="" class="pb-2">New Number</label>
                                        <input type="tel" class="form-control" value="<?php echo e($user->phone_no); ?>" name="phone_no">
                                    </div>

                                    <div class="form-group">
                                        <label for="" class="pb-2">Password</label>
                                        <input type="password" class="form-control" placeholder="" name="password">
                                    </div>
                                    <div class="d-flex justify-content-end pt-4">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>

                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="pb-5">
                <label for="">Email</label>
                <div class="row pt-2">
                    <div class="col-12 col-md-6">
                    <?php echo e(Auth::user()->email); ?>

                    </div>
                    <div class="col-12 col-md-6">
                        <a href="javascript:void(0)" data-toggle="modal" data-target="#change-email">Change Email</a>
                    </div>
                </div>
                <div class="modal fade" id="change-email" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content ">
                            <div class="px-3 text-center">
                                <h5 class="modal-title" id="exampleModalLabel">Change Email</h5>
                                <button type="button" class="close border-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                            <form id="profile" method="POST" action="<?php echo e(route('setting.account_email')); ?>">
                            <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="" class="pb-2">New Email</label>
                                        <input type="email" class="form-control" value="<?php echo e($user->email); ?>" name="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="pb-2">Password</label>
                                        <input type="password" class="form-control" placeholder="" name="password">
                                    </div>
                                    <div class="d-flex justify-content-end pt-4">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>

                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="pb-5">
                <label for="">Password</label>
                <div class="row pt-2">
                    <div class="col-12 col-md-6">
                        *************
                    </div>
                    <div class="col-12 col-md-6">
                        <a href="javascript:void(0)" data-toggle="modal" data-target="#change-password">Change Password</a>
                    </div>
                </div>
                <div class="modal fade" id="change-password" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content ">
                            <div class="px-3 text-center">
                                <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                                <button type="button" class="close border-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                            <form id="profile" method="POST" action="<?php echo e(route('setting.account_password')); ?>">
                            <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="" class="pb-2">Type Current Password</label>
                                        <input type="password" class="form-control" placeholder="CAB123456789" name="password">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="pb-2">New Password</label>
                                        <input type="password" class="form-control" placeholder="" name="new_password">
                                    </div>
                                    <div class="d-flex justify-content-end pt-4">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>

                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <!-- </form> -->

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\offseason\resources\views/setting/password_security.blade.php ENDPATH**/ ?>