

<?php $__env->startSection('content'); ?>
<div class="right-panel p-4">
    <div class="breadcrumb">
        <div><a href="<?php echo e(route('setting.index')); ?>" class="text-uppercase"><u>Settings</u></a></div>
        <div class="arrow mx-3"><i class="fa fa-angle-right"></i></div>
        <div class="text-uppercase"><u>Opration</u></div>
    </div>
    <div class="pt-4">
        <form method="post" action="<?php echo e(route('setting.opration_save')); ?>" class="operation-form">
            <?php echo csrf_field(); ?>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">Club fee (%)</label>
                <input type="text" class="form-control mb-0" size="1" name="club_fee" value="<?php echo e($opration->club_fee); ?>" />
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">minimum rate ($)</label>
                <input type="text" class="form-control mb-0" size="8" name="rate" value="<?php echo e($opration->rate); ?>" />
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">Monday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="mb-0" name="monday_status" id="monday_status">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="monday_open_time" name="monday_open_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="mid-line me-4"></div>
                <div class="form-group position-relative me-4 select-div">
                <select class="form-control mb-0" id="monday_close_time" name="monday_close_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">Tuesday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="mb-0" name="tuesday_status" id="tuesday_status">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="tuesday_open_time" name="tuesday_open_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="mid-line me-4"></div>
                <div class="form-group position-relative me-4 select-div">
                <select class="form-control mb-0" id="tuesday_close_time" name="tuesday_close_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">wednesday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="mb-0" name="wednesday_status" id="wednesday_status">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="wednesday_open_time" name="wednesday_open_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="mid-line me-4"></div>
                <div class="form-group position-relative me-4 select-div">
                <select class="form-control mb-0" id="wednesday_close_time" name="wednesday_close_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">thursday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="mb-0" name="thursday_status" id="thursday_status">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="thursday_open_time" name="thursday_open_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="mid-line me-4"></div>
                <div class="form-group position-relative me-4 select-div">
                <select class="form-control mb-0" id="thursday_close_time" name="thursday_close_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">friday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="mb-0" name="friday_status" id="friday_status">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="friday_open_time" name="friday_open_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="mid-line me-4"></div>
                <div class="form-group position-relative me-4 select-div">
                <select class="form-control mb-0" id="friday_close_time" name="friday_close_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">saturday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="mb-0" name="saturday_status" id="saturday_status">
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="saturday_open_time" name="saturday_open_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
                <div class="mid-line me-4"></div>
                <div class="form-group position-relative me-4 select-div">
                <select class="form-control mb-0" id="saturday_close_time" name="saturday_close_time">
                        <option value="8:00 AM">8:00 AM</option>
                        <option value="9:00 AM">9:00 AM</option>
                        <option value="10:00 AM">10:00 AM</option>
                        <option value="11:00 AM">11:00 AM</option>
                        <option value="12:00 AM">12:00 AM</option>
                        <option value="1:00 PM">1:00 PM</option>
                        <option value="2:00 PM">2:00 PM</option>
                        <option value="3:00 PM">3:00 PM</option>
                        <option value="4:00 PM">4:00 PM</option>
                        <option value="5:00 PM">5:00 PM</option>
                        <option value="6:00 PM">6:00 PM</option>
                        <option value="7:00 PM">7:00 PM</option>
                        <option value="8:00 PM">8:00 PM</option>
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="form-group d-flex align-items-center pb-4">
                <label for="" class="me-5">sunday:</label>
                <div class="form-group position-relative me-4 select-div">
                    <select class="form-control mb-0" id="sunday_status" name="sunday_status">
                        <option value="closed">Closed</option>
                        <option value="open">Open</option>
                        
                    </select>
                    <i class="fa fa-angle-down select-arrow"></i>
                </div>
            </div>
            <div class="d-flex justify-content-end pt-4">
            <a href="<?php echo e(route('setting.index')); ?>" class="btn me-5 border">Cancel</a>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>

        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\offseason\resources\views/setting/opration.blade.php ENDPATH**/ ?>