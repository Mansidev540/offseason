

<?php $__env->startSection('content'); ?>
<div class="right-panel p-4">
    <div class="breadcrumb">
        <div><a href="<?php echo e(route('roster.index')); ?>" class="text-uppercase"><u>Roster</u></a></div>
        <div class="arrow mx-3"><i class="fa fa-angle-right"></i></div>
        <div class="text-uppercase"><u><?php echo e($club->athlete_name); ?></u></div>
    </div>
    <div class="pt-4">
        <div class="d-flex justify-content-between">
            <div class="club-info d-flex">
                <div class="club-img me-4">
                    <img src="<?php echo e(asset('asset/images/MexicoSummer19-2.png')); ?>" alt="" width="100">
                </div>
                <div class="club-dt text-uppercase">
                    <h2><?php echo e($club->athlete_name); ?></h2>
                    
                </div>
            </div>
           
        </div>
        <div class="tab-div pt-4">

            <ul class="nav nav-tabs px-3">
                <li><a data-toggle="tab" href="#info" class="active">Info</a></li>
                <li><a data-toggle="tab" href="#schedule">Schedule</a></li>

            </ul>

            <div class="tab-content">
                <div id="info" class="tab-pane active py-4 px-3">
                    <?php $user = DB::table('users')->where('id',Auth::user()->id)->first();
                     ?>
                    <div class="pb-2"><label for="">First Name:</label><span> <?php echo e($user->name); ?></span></div>
                    <div class="pb-2"><label for="">Last Name:</label><span> <?php echo e($user->l_name); ?></span></div>
                    <div class="pb-2"><label for="">Email:</label><span> <?php echo e($user->email); ?></span></div>
                    <div class="pb-2"><label for="">Phone Number:</label><span> <?php echo e($club->phone_no); ?></span></div>
                    <div class="pb-2"><label for="">Birthday:</label><span> <?php echo e($club->dob); ?></span></div>
                    <div class="pb-2"><label for="">Gender:</label><span> <?php echo e($club->gender); ?></span></div>
                    <div class="pb-2"><label for="">Address:</label><span> <?php echo e($club->address); ?>,<?php echo e($club->city); ?>,<?php echo e($club->state); ?></span></div>
                </div>
                <div id="schedule" class="tab-pane fade py-4 px-3">

                    <div class="border-0">
                        <form autocomplete="off">
                            <div class="bg-dark">
                                <div class="mx-0 mb-0 row justify-content-sm-center justify-content-start px-1">
                                    <input type="text" id="dp1" class="datepicker" placeholder="Pick Date" name="date" readonly><span class="fa fa-calendar"></span>
                                </div>
                            </div>
                            <div class="p-3 p-sm-5">
                                <div class="row text-center mx-0">
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">8:00AM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">9:00AM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">10:00AM</div>
                                    </div>

                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">11:00AM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">12:00PM</div>
                                    </div>

                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">1:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">2:00PM</div>
                                    </div>

                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">3:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">4:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">5:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">6:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">7:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">8:00PM</div>
                                    </div>
                                </div>
                            </div>
                           
                            
                        </form>
                    </div>

                </div>
                <a href="javascript:void(0)" data-toggle="modal" data-target="#id_model" class="link" style="float:right" >Deactivate Partnership</a>
                <div class="modal fade" id="id_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content ">
                    <h3 class="text-center">Cancle Partnership: <?php echo e($club->athlete_name); ?> </h3>
                    <div class="modal-body">
                        <p class="text-center">To confirm , please type "Cancle" below</p>
                        <input type="text" name="email" class="form-control mb-0">
                        <div class="d-flex justify-content-center pt-4">
                        <a href="" class="btn btn-primary me-5">Enter</a>
                            <a href="" class="btn btn-primary">Cancle</a>
                        </div>
                    </div>

                </div>
                
            </div>
        </div>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\offseason\resources\views/roster/detail.blade.php ENDPATH**/ ?>