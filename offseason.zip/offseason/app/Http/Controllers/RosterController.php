<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Athlete;
use DB;

class RosterController extends Controller
{
    public function index()
    {
        $roster = Athlete::all(); 
        return view('roster.index',compact('roster'));
    }
    public function detail($id)
    { 
        $club = Athlete::where('id',$id)->first();
        return view('roster.detail',compact('club'));
    }
}
