<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Club;
use DB;

class ClubModuleController extends Controller
{
    public function index()
    {
        $club = Club::all();
        return view('club.index',compact('club'));
    }
    public function detail($id)
    { 
        $club = Club::where('id',$id)->first();
        $opration = DB::table('opration')->where('club_id',$club->id)->first();
        return view('club.detail',compact('club','opration'));
    }
}
