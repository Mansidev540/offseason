$(".drop-toggle").click(function(e) {
    e.preventDefault();
    $(this).siblings(".drop-div").toggle();
});

/* databese table */




/* datepicker js */
// $('.datepicker').datepicker({
//     format: 'dd-mm-yyyy',
//     autoclose: true,
//     startDate: '0d',
//     var selected = $(this).datepicker("getDate");
//     alert(selected);
    
// });
$(function() {
    $(".datepicker").datepicker({ 
        dateFormat: "yy-mm-dd", 
        onSelect: function(){
            var selected = $(this).datepicker("getDate");
            alert(selected);
        }
    });
});

 	

$( ".cell" ).on( "click", function() {
    //$('.cell').removeClass('select');
    
    $(this).toggleClass('select');
});

