@extends('layouts.app')

@section('content')
<div class="right-panel p-4">
    <div class="breadcrumb">
        <div><a href="{{ route('club.index') }}" class="text-uppercase"><u>Clubs</u></a></div>
        <div class="arrow mx-3"><i class="fa fa-angle-right"></i></div>
        <div class="text-uppercase"><u>{{$club->club_name}}</u></div>
    </div>
    <div class="pt-4">
        <div class="d-flex justify-content-between">
            <div class="club-info d-flex">
                <div class="club-img me-4">
                    <img src="{{ asset('asset/images/MexicoSummer19-2.png') }}" alt="" width="100">
                </div>
                <div class="club-dt text-uppercase">
                    <h2>{{$club->club_name}}</h2>
                    <div><label for="">Club Fee:</label> {{$opration->club_fee}}%</div>
                </div>
            </div>
            <div class="bookin-info">
                <form action="" class="operation-form">
                    <div class="form-group d-flex align-items-center pb-4">
                        <label class="me-3 text-end">Available</label>
                        <label class="switch m5">
                            <input type="checkbox" selected="selected" readonly="readonly">
                            <small></small>
                        </label>
                    </div>
                    <div class="form-group d-flex align-items-center pb-4">
                        <label for="" class="me-3 text-end">Booking Rate ($)</label>
                        <input type="text" class="form-control mb-0" value="{{$opration->rate}}" size="5" readonly="readonly">
                    </div>
                </form>
            </div>
        </div>
        <div class="tab-div pt-4">

            <ul class="nav nav-tabs px-3">
                <li><a data-toggle="tab" href="#info" class="active">Info</a></li>
                <li><a data-toggle="tab" href="#schedule">Schedule</a></li>

            </ul>

            <div class="tab-content">
                <div id="info" class="tab-pane active py-4 px-3">
                <?php $user = DB::table('users')->where('id',Auth::user()->id)->first(); ?>
                    <div class="pb-2"><label for="">Email:</label><span> {{$user->email}}</span></div>
                    <div class="pb-2"><label for="">Phone Number:</label><span> {{$club->phone_no}}</span></div>
                    <div class="pb-2"><label for="">Address:</label><span> {{$club->address}},{{$club->city}},{{$club->state}}</span></div>
                </div>
                <div id="schedule" class="tab-pane fade py-4 px-3">

                    <div class="border-0">
                        <form autocomplete="off">
                            <div class="bg-dark">
                                <div class="mx-0 mb-0 row justify-content-sm-center justify-content-start px-1">
                                    <input type="text" id="dp1" class="datepicker" placeholder="Pick Date" name="date" readonly><span class="fa fa-calendar"></span>
                                </div>
                            </div>
                            <div class="p-3 p-sm-5">
                                <div class="row text-center mx-0">
                                <div class="row text-center mx-0">
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">8:00AM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">9:00AM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">10:00AM</div>
                                    </div>

                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">11:00AM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">12:00PM</div>
                                    </div>

                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">1:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">2:00PM</div>
                                    </div>

                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">3:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">4:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">5:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">6:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">7:00PM</div>
                                    </div>
                                    <div class="col-md-2 col-4 my-1 px-2">
                                        <div class="cell py-1">8:00PM</div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                            <button type="submit" class="btn btn-primary center">Save</button>
                            </div>
                        </form>
                    </div>

                </div>
                

            </div>
            <a href="javascript:void(0)" data-toggle="modal" data-target="#id_model" class="link" style="float:right" >Deactivate Partnership</a>
                <div class="modal fade" id="id_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content ">
                            <h3 class="text-center">Cancle Partnership: {{$club->club_name}} </h3>
                            <div class="modal-body">
                                <p class="text-center">To confirm , please type "Cancle" below</p>
                                <input type="text" name="email" class="form-control mb-0">
                                <div class="d-flex justify-content-center pt-4">
                                <a href="" class="btn btn-primary me-5">Enter</a>
                                    <a href="" class="btn btn-primary">Cancle</a>
                                </div>
                            </div>

                        </div>
                
                </div>
        </div>
        </div>


    </div>
</div>
@endsection
