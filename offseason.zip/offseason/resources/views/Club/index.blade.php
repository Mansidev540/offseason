
@extends('layouts.app')

@section('content')
<div class="right-panel p-4">
    <div class="d-flex pb-4">
        <div class="flex-grow-1 d-flex align-items-center">
            <h2 class="text-uppercase me-4 mb-0">Club</h2>
                <!-- <div class="form-group">
                    <input type="search" class="form-control mb-0 search-input" placeholder="Search" />
                </div> -->
           
        </div>

    </div>
    <!-- <div class="listing-data px-3">
        <div class="row border-bottom py-3 list-head">
            <div class="col-sm-8 col-lg-10">Name</div>
            <div class="col-sm-2 col-lg-1">Price</div>
            <div class="col-sm-2 col-lg-1"></div>
        </div>
       
      

    </div>-->
    <div class="table-responsive pb-5 pt-4">
        <table class="table dt-responsive nowrap" id="responsive-data-table">
            <!-- <tr>
                <th width="75%" class="py-3">Name</th>
                <th width="15%" class="py-3">Price</th>
                <th width="10%" class="py-3"></th>
            </tr> -->
            <!-- <thead>
                <tr>
                    <th width="25%" class="py-3">Name</th>
                    <th width="30%" class="py-3">Location</th>
                    <th width="30%" class="py-3">Number</th>
                    <th width="30%" class="py-3">Status</th>
                </tr>
            </thead> -->
            <thead>
                        <tr>
                        <th width="25%" class="py-3">Name</th>
                        <th width="30%" class="py-3">Location</th>
                        <th width="30%" class="py-3">Number</th>
                        <th width="30%" class="py-3">Status</th>
                        </tr>
                    </thead>
            @foreach($club as $value)
            <tr>
                <td class="py-4">
                    <table cellpadding="0" cellspacing="0" width="100%" class="border-none">
                        <tr>
                            <td width="80">
                                <a href="{{route('club.detail',$value->id)}}"><img src="{{ asset('asset/images/MexicoSummer19-2.png') }}" alt="" width="56"></a>
                            </td>
                            <td><a href="{{route('club.detail',$value->id)}}" class="link">{{$value->club_name}}</a></td>
                        </tr>
                    </table>

                </td>
                <td class="py-4" valign="middle">{{$value->city}},{{$value->state}}</td>
                <td class="py-4" valign="middle">{{$value->phone_no}}</td>
                <td class="py-4" valign="middle" style="color:green">Available</td>

            </tr>
            @endforeach


        </table>
       
    </div>

</div>
@endsection
@section('script')

<!-- <script>
$(document).ready( function () {
    $('#responsive-data-table').DataTable();
} );
</script> -->
@endsection
